---
name: Institutional Rigor & Precision Risk
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#44474d'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#75777e'
  outline-variant: '#c4c6ce'
  surface-tint: '#4d5f7d'
  primary: '#000615'
  on-primary: '#ffffff'
  primary-container: '#0b1f3a'
  on-primary-container: '#7587a7'
  inverse-primary: '#b5c7ea'
  secondary: '#006b5f'
  on-secondary: '#ffffff'
  secondary-container: '#6df5e1'
  on-secondary-container: '#006f64'
  tertiary: '#000517'
  on-tertiary: '#ffffff'
  tertiary-container: '#001d48'
  on-tertiary-container: '#3c83f7'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d6e3ff'
  primary-fixed-dim: '#b5c7ea'
  on-primary-fixed: '#071c36'
  on-primary-fixed-variant: '#364764'
  secondary-fixed: '#71f8e4'
  secondary-fixed-dim: '#4fdbc8'
  on-secondary-fixed: '#00201c'
  on-secondary-fixed-variant: '#005048'
  tertiary-fixed: '#d8e2ff'
  tertiary-fixed-dim: '#adc6ff'
  on-tertiary-fixed: '#001a42'
  on-tertiary-fixed-variant: '#004395'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.025em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  stat-xl:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  stat-lg:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-base:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-bold:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm-medium:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  table-header:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.06em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system establishes a high-assurance financial technology aesthetic engineered for bank underwriting officers, risk committees, and quantitative machine learning researchers. It balances uncompromised institutional credibility with algorithmic precision. The user interface prioritizes calm authority, intense optical clarity, and cognitive comfort during prolonged review sessions of complex probabilistic models and lending portfolios.

The visual style blends modern corporate clarity with technical data density. Surfaces are characterized by pristine white containers floating over cool slate canvases, framed by hairline borders and anchored by an authoritative deep navy foundation. Vibrant teal interactive cues guide analytical workflows and parameter calibrations, while an uncompromising tripartite semantic color framework signals loan default risk instantly without ambiguity.

## Colors

The palette establishes an unmistakable hierarchy between structural chrome, interactive elements, analytical canvases, and critical risk decisions.

### Primary Foundation & Canvases
- **Primary Navy (`#0B1F3A`)**: The institutional anchor. Applied to navigation rails, key headers, high-level action buttons, and dark modal headers. Variations include `#16335B` for hover/accent states and `#061324` for active pressed states.
- **Secondary Teal (`#14B8A6`)**: Interactive and algorithmic accent. Highlights parameter controls, slider tracks, model confidence states, active indicators, and secondary calls-to-action. State variants include `#0D9488` (hover) and `#CCFBF1` (subtle selection fill).
- **Tertiary Blue (`#3B82F6`)**: Informational accents, audit trail markers, secondary model series comparisons, and system notice callouts.
- **Neutral Canvas (`#F8FAFC`)**: Cool, glare-reducing application canvas background. Paired with `#F1F5F9` for secondary panel strips, segmented controls, and alternating rows, and `#FFFFFF` for elevated analytic cards.

### Semantic Risk Triad
- **Low Risk / Approve**: Primary `#10B981` (Emerald Green), subtle tint `#D1FAE5`, high-contrast text `#065F46`.
- **Medium Risk / Manual Review**: Primary `#F59E0B` (Amber Orange), subtle tint `#FEF3C7`, high-contrast text `#92400E`.
- **High Risk / Reject**: Primary `#EF4444` (Rose Red), subtle tint `#FEE2E2`, high-contrast text `#991B1B`.

### Dark Mode Tokens
Complementary dark palette for quantitative research environments:
- Canvas: `#070F1E`
- Card Surface: `#0B1F3A`
- Surface Elevated: `#132B4F`
- Dark Border: `#1E3A5F`
- Dark Text Primary: `#F8FAFC`
- Dark Text Secondary: `#94A3B8`
- Translucent Risk Badges: Green (`rgba(16, 185, 129, 0.16)`), Amber (`rgba(245, 158, 11, 0.16)`), Rose (`rgba(239, 68, 68, 0.16)`).

## Typography

The typographical system relies entirely on **Inter** to deliver a neutral, disciplined, and functional tone across enterprise dashboards and computational views. 

### Tabular Numbers Rule
For all monetary amounts, basis points, credit scores, default probabilities, and statistical indices, enforce OpenType tabular figures (`font-feature-settings: "tnum" 1, "cv05" 1`). This guarantees strict vertical column alignment across dense financial data grids.

### Case and Tracking Conventions
- Section headers and card titles use sentence casing with subtle negative tracking for cohesion.
- Table headers (`table-header`) and risk tags (`label-caps`) enforce uppercase transformation with positive letter-spacing (`+0.05em` to `+0.06em`) for rapid scanability at compact sizes.
- Monospace snippets (model variables, regulatory XML schemas, and raw calculations) should utilize a complementary monospaced font at 13px / 18px line height.

## Layout & Spacing

The layout is constructed on a strict 4px/8px incremental grid. It utilizes a 12-column responsive layout engine capped at 1440px for widescreen stability, flanked by dynamic margins.

### Layout Partitioning
- **Primary Viewport**: Structured as an asymmetric dual-pane dashboard. Columns 1–8 accommodate portfolio distribution graphs, confusion matrices, and the primary loan pipeline table. Columns 9–12 anchor the sticky Underwriter Dossier / Inspection Drawer for single-applicant deep dives.
- **Breakpoints**:
  - **Desktop (≥ 1280px)**: 12-column grid, 24px (`1.5rem`) gutters, 32px (`2rem`) margins, persistent 260px navigation sidebar.
  - **Tablet (768px – 1279px)**: 8-column grid, 16px (`1rem`) gutters, 24px (`1.5rem`) margins, collapsed 72px icon rail. Inspection drawers shift to slide-over panels.
  - **Mobile (< 768px)**: 4-column single-stack grid, 16px gutters, 16px margins, sticky bottom decision bar. Tables scroll horizontally with pinned key columns.

## Elevation & Depth

Visual hierarchy is maintained through delicate tonal stratification, hairline containment, and soft ambient shadows rather than stark layered drops.

### Elevation Levels
- **Level 0 (Flat Canvas)**: Resting application canvas (`#F8FAFC`). No shadow.
- **Level 1 (Analytical Cards & Surfaces)**: Pure white `#FFFFFF` surface containers framed with a 1px solid hairline border (`#E2E8F0`). Shadow: `0 1px 3px 0 rgba(15, 23, 42, 0.04), 0 1px 2px -1px rgba(15, 23, 42, 0.03)`.
- **Level 2 (Interactive Hover & Active Cards)**: Hovered applicant rows and floating toolbars. Border deepens to `#CBD5E1`. Shadow: `0 10px 15px -3px rgba(15, 23, 42, 0.06), 0 4px 6px -4px rgba(15, 23, 42, 0.04)`.
- **Level 3 (Inspection Drawers & Modals)**: Critical underwriter override modals and applicant profile flyouts. Shadow: `0 20px 25px -5px rgba(15, 23, 42, 0.1), 0 8px 10px -6px rgba(15, 23, 42, 0.06)`. Accompanied by a 30% `#0B1F3A` backdrop scrim.

## Shapes

The design system uses a balanced rounded shape language. Corner geometry follows an intentional scale:

- **Surface Cards & Modal Containers**: Standardized on `rounded-xl` (1rem / 16px) to give expansive data cards an approachable, contained presence.
- **Buttons, Form Inputs, and Dropdowns**: Scaled to `rounded-lg` (0.5rem / 8px), preserving crisp mechanical geometry suitable for enterprise financial software.
- **Status Pills, Risk Badges, and Slider Thumbs**: Fully circular (`rounded-full`), clearly distinguishing metadata tags and interactive knobs from card containers.

## Components

### Buttons
- **Primary Navy**: Background `#0B1F3A`, text `#FFFFFF`, radius 8px (`rounded-lg`), height 40px (medium) or 48px (decision action). Hover `#16335B`.
- **Teal Action**: Background `#14B8A6`, text `#FFFFFF`, radius 8px. Hover `#0D9488` with subtle glow `0 0 12px rgba(20, 184, 166, 0.3)`. Used for calculation triggers and parameter deployments.
- **Risk Decision Actions**: Dedicated colorways for final actions: Approve (`#10B981`), Review (`#F59E0B`), Reject (`#EF4444`).
- **Secondary / Outline**: Background `#FFFFFF`, 1px solid border `#CBD5E1`, text `#0F172A`. Hover `#F8FAFC`.

### Chips & Semantic Risk Badges
- Pill shape (`rounded-full`), height 24px, padding `px-2.5 py-0.5`. Text set in `label-caps` (11px, bold, uppercase).
- Always include a 6px status dot alongside text to satisfy accessibility requirements:
  - **Approve**: Surface `#D1FAE5`, text `#065F46`, dot `#10B981`.
  - **Review**: Surface `#FEF3C7`, text `#92400E`, dot `#F59E0B`.
  - **Reject**: Surface `#FEE2E2`, text `#991B1B`, dot `#EF4444`.

### Input Fields & Interactive Controls
- **Form Inputs**: White `#FFFFFF` background, 1px `#CBD5E1` border, 8px corner radius, height 40px. Focus state applies a `#14B8A6` border and a 3px ring (`rgba(20, 184, 166, 0.2)`). Labels rest above inputs in `body-sm-medium` (`#475569`).
- **Parameter Sliders**: Track height 6px, rounded full, inactive fill `#E2E8F0`, active fill `#14B8A6`. Knob is a 20px circle with solid `#FFFFFF` fill, 2px `#0B1F3A` border, and drop shadow. Floating pill tooltip above knob reveals live numeric probability cutoffs.
- **Checkboxes & Radios**: 18px base with 4px corner radius (checkbox) or circular (radio). Inactive border 1.5px `#CBD5E1`. Checked state fills `#0B1F3A` (or `#14B8A6` in calibration panels) with white check icon.

### Cards & Dossiers
- Clean `#FFFFFF` fill, 16px corner radius (`rounded-xl`), 1px `#E2E8F0` border. Standard padding 24px (`space-lg`), compact metric blocks 16px, dossier summaries 32px.

### Tabular Risk Matrices
- High-density table architecture. Header cells (`<th>`) set to `#F8FAFC`, 12px uppercase font, tracking `+0.05em`, `#64748B` text, 2px `#E2E8F0` bottom boundary.
- Data rows (`<tr>`) alternate subtly between `#FFFFFF` and `#FAFAFC`, height 48px, hover fill `#F1F5F9`. Selected row triggers a light teal tint (`rgba(20, 184, 166, 0.06)`) and a 2px `#14B8A6` left edge marker. Numbers strictly use tabular figures.

### Explainability Visualizations
- **SHAP Feature Bars**: Bi-directional horizontal bars displaying factor weights. Adverse factors push right in Rose (`#EF4444`); risk-mitigating factors push left in Emerald (`#10B981`).
- **Risk Score Gauge**: Segmented or radial meter split into 3 core risk tiers (0–250 Green, 251–650 Amber, 651–1000 Rose) with a high-contrast `#0B1F3A` needle indicator.